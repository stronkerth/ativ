from django.contrib import admin
from .models import Rotina
from .models import Tarefa

admin.site.register(Rotina)
admin.site.register(Tarefa)