from django.db import models

# Create your models here.
class Rotina(models.Model):
  afazeres = models.CharField(max_length = 50)
  horario = models.TextField()
  prazo = models.DateField()
  done = models.BooleanField()

class Tarefa(models.Model):
  necessidades = models.CharField(max_length = 50)
  horario = models.TextField()
  prazo = models.DateField()
  done = models.BooleanField()
