from django.apps import AppConfig


class AppdothiagoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appdothiago'
