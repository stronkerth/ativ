from django.shortcuts import render, redirect
from .models import Rotina
from .models import Tarefa


def home(request):
    rotinas = Rotina.objects.all()
    tarefas = Tarefa.objects.all()
    context = {"rotinas": rotinas,"tarefas": tarefas}
    return render(request, "home.html", context=context)


def list_rotinas(request):
    rotinas = Rotina.objects.all()
    context = {"rotinas": rotinas}
    return render(request, "list_rotinas.html", context=context)
  
def list_tarefas(request):
    tarefas = Tarefa.objects.all()
    context = {"tarefas": tarefas}
    return render(request, "list_tarefas.html", context=context)

def create_rotina(request):
    if request.method == "POST":
        if "done" not in request.POST:
            done = False
        else:
            done = True
        Rotina.objects.create(afazeres=request.POST["afazeres"],
                            horario=request.POST["horario"],
                            prazo=request.POST["prazo"],
                            done=done)
        return redirect("rotinas-list")

    return render(request, "Rotina_form.html")


def update_rotina(request, rotina_id):
    rotina = Rotina.objects.get(id=rotina_id)
    rotina.due_date = rotina.due_date.strftime('%Y-%m-%d')

    if request.method == "POST":
        rotina.title = request.POST["title"]
        rotina.description = request.POST["description"]
        rotina.due_date = request.POST["due-date"]
        if "done" not in request.POST:
            rotina.done = False
        else:
            rotina.done = True
        rotina.save()
        return redirect("rotinas-list")

    return render(request, "rotina_form.html", context={"rotina": rotina})


def delete_rotina(request, rotina_id):
    rotina = Rotina.objects.get(id=rotina_id)
    if request.method == "POST":
      if "confirm" in request.POST:
        rotina.delete()

      return redirect("rotinas-list")

    return render(request, "delete_form.html", context={"rotina": rotina})

def create_tarefa(request):
    if request.method == "POST":
        if "done" not in request.POST:
            done = False
        else:
            done = True
        Tarefa.objects.create(necessidades=request.POST["necessidades"],
                            horario=request.POST["horario"],
                            prazo=request.POST["prazo"],
                            done=done)
        return redirect("tarefas-list")

    return render(request, "Tarefa_form.html")


def update_tarefa(request, tarefa_id):
    tarefa = Tarefa.objects.get(id=tarefa_id)
    tarefa.due_date = tarefa.due_date.strftime('%Y-%m-%d')

    if request.method == "POST":
        tarefa.title = request.POST["title"]
        tarefa.description = request.POST["description"]
        tarefa.due_date = request.POST["due-date"]
        if "done" not in request.POST:
            tarefa.done = False
        else:
            tarefa.done = True
        tarefa.save()
        return redirect("tarefas-list")

    return render(request, "tarefa_form.html", context={"tarefa": tarefa})


def delete_tarefa(request, tarefa_id):
    tarefa = Tarefa.objects.get(id=tarefa_id)
    if request.method == "POST":
      if "confirm" in request.POST:
        tarefa.delete()

      return redirect("tarefas-list")

    return render(request, "delete_form.html", context={"tarefa": tarefa})

