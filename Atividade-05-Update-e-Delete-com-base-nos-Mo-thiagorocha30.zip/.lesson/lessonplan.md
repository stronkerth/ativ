# Atividade 04

**PRINCIPAL (700XP)**
- Criar um novo template com formulário para cada modelo criado;
- Associar cada template a uma nova view e url separadas;
- Após a submissão de cada formulário, o site deve ser redirecionado para página principal (com as listas);
- Adicionar o CSS da página que não foi adicionado ainda;

**EXTRA (100XP)**
- Fazer o formulário para a tabela usando Django Forms (forms.py).