# Atividade 05

**PRINCIPAL (700XP)**
- Obrigatoriamente todas as listas devem aparecer na página principal, como expliquei em sala;
- Adicionar o CSS da página que não foi adicionado ainda;
- Para cada item de cada lista (ul e ol), deve haver um link para editar e remover ele;
- Devem ser criadas novas urls para edição e remoção de um item do modelo que criaram;

**EXTRA (200XP)**
- Fazer a edição e remoção para os dados da tabela usando Django Forms (forms.py).